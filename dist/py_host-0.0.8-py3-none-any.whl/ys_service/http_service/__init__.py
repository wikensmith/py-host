#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# @Time    : 2019/11/12 14:16
# @Author  : v5yangzai
# @Site    : https://github.com/v5yangzai
# @File    : __init__.py.py
# @project : ys_module
# @Software: PyCharm
# @Desc    :


if __name__ == "__main__":
    ...
