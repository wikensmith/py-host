#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# @Time    : 2019/11/12 14:45
# @Author  : v5yangzai
# @Site    : https://github.com/v5yangzai
# @File    : http_service.py
# @project : ys_module
# @Software: PyCharm
# @Desc    :

import requests


class HTTPService(object):

    def __init__(self):
        pass

    # @property
    # def log_create(self):
    #     """
    #     创建 log_center 对象
    #     :return: 实例对象
    #     """
    #
    #     return LogCreate().create
    #
    # @property
    # def mq_create(self):
    #     """
    #     创建 mq 对象
    #     :return: 实例对象
    #     """
    #
    #     return CreateMQ().create

